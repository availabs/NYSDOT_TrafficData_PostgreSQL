# Inspecting the CSVs

## Pre-inspection cleaning

Trim whitespace from column values:

``` bash
find -name '*.csv' -exec sed -i 's/ *, */,/g' {} ';'
```

Remove empty lines:

``` bash
find -name '*.csv' -exec sed -i '/^$/d' {} ';'
```

Remove Windows line endings:

``` bash
find -name '*.csv' -exec sed -i 's/\r//g' {} ';'
```

## Validating file headers

The following command was used to verify that the headers are the same for all CSVs of the same type.

``` bash
for f in *; do echo "===== ${f} =====" ; find $f -name '*.csv' -exec head -1 {} ';' | sort -u; echo; done > headers
```

Visual inspection of the output shows that this is true except for the following file that is missing its header.

The ./noHeader.sh script identifies the missing-header file as 'SC\_Class\_Data\_R10\_2013.csv'

## Files with 'rows selected'

``` bash
ag 'rows selected' -l
```

Output:
```
short_count_speed/2011/R01/SC_Speed_Data_R01_2011.csv
short_count_speed/2011/R05/SC_Speed_Data_R05_2011.csv
short_count_speed/2014/R08/SC_Speed_Data_R08_2014.csv
```

## File with '---,---' line

```
ag '\-,\-' -l
```

Output:
```
average_weekday_vehicle_classification/2011/R09/SC_CLASS_AVGWD_R09_2011.csv
```

