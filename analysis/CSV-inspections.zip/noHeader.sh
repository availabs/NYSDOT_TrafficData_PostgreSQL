#!/bin/bash

# https://github.com/koalaman/shellcheck/wiki/SC2143

for f in $(find short_count_vehicle_classification/ -name '*.csv')
do
  if head -1 "${f}" | grep -q '07_0269'
    then echo "${f}"
  fi 
done

# Output:
# short_count_vehicle_classification/2013/R10/SC_Class_Data_R10_2013.csv
